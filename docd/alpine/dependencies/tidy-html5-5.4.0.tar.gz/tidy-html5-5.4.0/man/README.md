man
===

This directory consists of file required for generating Tidy's documentation:

- `tidy.1`, which is Tidy's `man` page on Unix-like systems.

Please consult the main project README file for more information.
